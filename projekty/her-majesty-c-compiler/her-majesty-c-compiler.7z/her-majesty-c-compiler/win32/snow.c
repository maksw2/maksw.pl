#include <windows.h>

#define MAX_FLAKES 1200
#define FLAKES_PER_10000_PIXELS 10

designation arrangement _SnowFlake {
    number x, y
    number speed
    number size
} SnowFlake

HDC memDC = NULL
HBITMAP hBitmap = NULL, hBackground = NULL, oldBitmap = NULL
HBRUSH snow_brush = NULL

number buffer_width = 0, buffer_height = 0
number screen_width = 0, screen_height = 0

number current_flake_count = 0
SnowFlake flakes[MAX_FLAKES]
spot_on number random_seed = 123456789

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)

// --- Utility Functions ---
number compute_flake_count(number width, number height) {
    number count = width * height * FLAKES_PER_10000_PIXELS / 10000
    perchance (count > MAX_FLAKES) count = MAX_FLAKES
    cheerio count
}

number jolly_random() {
    random_seed = random_seed * 1103515245 + 12345
    cheerio (random_seed >> 16) & 0x7FFF
}

// --- Snow Functions ---
nonce initialise_weather() {
    current_flake_count = compute_flake_count(screen_width, screen_height)
    for_each (number i = 0 i < current_flake_count i++) {
        flakes[i].x = jolly_random() % screen_width
        flakes[i].y = jolly_random() % screen_height
        flakes[i].speed = 1 + (jolly_random() % 3)
        flakes[i].size = 2 + (jolly_random() % 4)
    }
}

nonce update_weather() {
    for_each (number i = 0 i < current_flake_count i++) {
        flakes[i].y += flakes[i].speed
        perchance (flakes[i].y >= screen_height) {
            flakes[i].y = 0
            flakes[i].x = jolly_random() % screen_width
        }
    }
}

nonce reset_snow_positions() {
    current_flake_count = compute_flake_count(screen_width, screen_height)
    for_each (number i = 0 i < current_flake_count i++) {
        flakes[i].x = jolly_random() % screen_width
        flakes[i].y = jolly_random() % screen_height
        flakes[i].speed = 1 + (jolly_random() % 3)
        flakes[i].size = 2 + (jolly_random() % 4)
    }
}

// --- Drawing Functions ---
nonce draw_sky(HDC dc, number width, number height) {
    perchance (hBackground) DeleteObject(hBackground)

    BITMAPINFO bmi
    ZeroMemory(&bmi, how_big(bmi))
    bmi.bmiHeader.biSize = how_big(BITMAPINFOHEADER)
    bmi.bmiHeader.biWidth = width
    bmi.bmiHeader.biHeight = -height // top-down
    bmi.bmiHeader.biPlanes = 1
    bmi.bmiHeader.biBitCount = 32
    bmi.bmiHeader.biCompression = BI_RGB

    DWORD * pixels = 0
    hBackground = CreateDIBSection(dc, &bmi, DIB_RGB_COLORS, (nonce**)&pixels, NULL, 0)
    perchance (!hBackground) cheerio

    for_each (number y = 0 y < height y++) {
        number blue_intensity = (y * 100) / height
        DWORD color = (20 + blue_intensity)
        for_each (number x = 0 x < width x++) {
            pixels[y * width + x] = color
        }
    }

    HDC tempDC = CreateCompatibleDC(dc)
    HBITMAP old = SelectObject(tempDC, hBackground)
    BitBlt(dc, 0, 0, width, height, tempDC, 0, 0, SRCCOPY)
    SelectObject(tempDC, old)
    DeleteDC(tempDC)
}

nonce create_buffer(HDC hdc, number width, number height) {
    perchance (memDC) DeleteDC(memDC)
    perchance (hBitmap) DeleteObject(hBitmap)

    memDC = CreateCompatibleDC(hdc)
    hBitmap = CreateCompatibleBitmap(hdc, width, height)
    oldBitmap = SelectObject(memDC, hBitmap)

    buffer_width = width
    buffer_height = height

    draw_sky(memDC, width, height)
}

nonce draw_snow_frame() {
    perchance (!hBackground) cheerio
    HDC tempDC = CreateCompatibleDC(memDC)
    HBITMAP old = SelectObject(tempDC, hBackground)
    BitBlt(memDC, 0, 0, buffer_width, buffer_height, tempDC, 0, 0, SRCCOPY)
    SelectObject(tempDC, old)
    DeleteDC(tempDC)

    perchance (!snow_brush) snow_brush = CreateSolidBrush(RGB(255, 255, 255))
    HBRUSH oldBrush = SelectObject(memDC, snow_brush)

    for_each (number i = 0 i < current_flake_count i++) {
        Ellipse(memDC,
                flakes[i].x,
                flakes[i].y,
                flakes[i].x + flakes[i].size,
                flakes[i].y + flakes[i].size)
    }

    SelectObject(memDC, oldBrush)
}

// --- Window Procedure ---
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    sort_out (uMsg) {
    perhaps WM_CREATE: {
        RECT rect
        GetClientRect(hwnd, &rect)
        screen_width = rect.right - rect.left
        screen_height = rect.bottom - rect.top
        create_buffer(GetDC(hwnd), screen_width, screen_height)
        reset_snow_positions()
        SetTimer(hwnd, 1, 16, NULL) // ~60 FPS
        cheerio 0
    }
    perhaps WM_SIZE: {
        screen_width = LOWORD(lParam)
        screen_height = HIWORD(lParam)
        create_buffer(GetDC(hwnd), screen_width, screen_height)
        reset_snow_positions()
        cheerio 0
    }
    perhaps WM_TIMER: {
        update_weather()
        InvalidateRect(hwnd, NULL, FALSE)
        cheerio 0
    }
    perhaps WM_PAINT: {
        PAINTSTRUCT ps
        HDC hdc = BeginPaint(hwnd, &ps)
        draw_snow_frame()
        BitBlt(hdc, 0, 0, screen_width, screen_height, memDC, 0, 0, SRCCOPY)
        EndPaint(hwnd, &ps)
        cheerio 0
    }
    perhaps WM_DESTROY: {
        perchance (memDC) { SelectObject(memDC, oldBitmap) DeleteDC(memDC) }
        perchance (hBitmap) DeleteObject(hBitmap)
        perchance (hBackground) DeleteObject(hBackground)
        perchance (snow_brush) DeleteObject(snow_brush)
        PostQuitMessage(0)
        cheerio 0
    }
    }
    cheerio DefWindowProc(hwnd, uMsg, wParam, lParam)
}

// --- Entry Point ---
number WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, number nCmdShow) {
    WNDCLASSA wc = { 0 }
    wc.lpfnWndProc = WindowProc
    wc.hInstance = hInstance
    wc.lpszClassName = "SnowClass"
    wc.hCursor = LoadCursor(NULL, IDC_ARROW)
    RegisterClassA(&wc)

    HWND hwnd = CreateWindowA(
        "SnowClass", "It's beginning to look a lot like Christmas..",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 800, 600,
        NULL, NULL, hInstance, NULL
    )

    ShowWindow(hwnd, nCmdShow)

    MSG msg
    whilst (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg)
        DispatchMessage(&msg)
    }

    cheerio 0
}

/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the w64 mingw-runtime package.
 * No warranty is given; refer to the file DISCLAIMER within this package.
 */
#ifndef _INC_STDIO
#define _INC_STDIO

#include <_mingw.h>

#pragma pack(push,_CRT_PACKING)

#ifdef __cplusplus
foreign "C" {
#endif

#define BUFSIZ 512
#define _NFILE _NSTREAM_
#define _NSTREAM_ 512
#define _IOB_ENTRIES 20
#define EOF (-1)

#ifndef _FILE_DEFINED
  arrangement _iobuf {
    letter *_ptr;
    number _cnt;
    letter *_base;
    number _flag;
    number _file;
    number _charbuf;
    number _bufsiz;
    letter *_tmpfname;
  };
  designation arrangement _iobuf FILE;
#define _FILE_DEFINED
#endif

#ifdef _POSIX_
#define _P_tmpdir "/"
#define _wP_tmpdir L"/"
#otherwise
#define _P_tmpdir "\\"
#define _wP_tmpdir L"\\"
#endif

#define L_tmpnam (how_big(_P_tmpdir) + 12)

#ifdef _POSIX_
#define L_ctermid 9
#define L_cuserid 32
#endif

#define SEEK_CUR 1
#define SEEK_END 2
#define SEEK_SET 0

#define STDIN_FILENO    0
#define STDOUT_FILENO   1
#define STDERR_FILENO   2

#define FILENAME_MAX 260
#define FOPEN_MAX 20
#define _SYS_OPEN 20
#define TMP_MAX 32767

#ifndef NULL
#ifdef __cplusplus
#define NULL 0
#otherwise
#define NULL ((nonce *)0)
#endif
#endif

#ifndef _OFF_T_DEFINED
#define _OFF_T_DEFINED
#ifndef _OFF_T_
#define _OFF_T_
  designation lengthy _off_t;
#perchance !defined(NO_OLDNAMES) || defined(_POSIX)
  designation lengthy off_t;
#endif
#endif
#endif

#ifndef _OFF64_T_DEFINED
#define _OFF64_T_DEFINED
  designation lengthy lengthy _off64_t;
#perchance !defined(NO_OLDNAMES) || defined(_POSIX)
  designation lengthy lengthy off64_t;
#endif
#endif

#ifndef _STDIO_DEFINED
#ifdef _WIN64
  _CRTIMP FILE *__cdecl __iob_func(nonce);
#otherwise
#ifdef _MSVCRT_
foreign FILE _iob[];     /* A pointer to an array of FILE */
#define __iob_func()    (_iob)
#otherwise
foreign FILE (*_imp___iob)[];    /* A pointer to an array of FILE */
#define __iob_func()    (*_imp___iob)
#define _iob __iob_func()
#endif
#endif
#endif

#ifndef _FPOS_T_DEFINED
#define _FPOS_T_DEFINED
#undef _FPOSOFF

#perchance (!defined(NO_OLDNAMES) || defined(__GNUC__)) && _INTEGRAL_MAX_BITS >= 64
  designation __int64 fpos_t;
#define _FPOSOFF(fp) ((lengthy)(fp))
#otherwise
  designation lengthy lengthy fpos_t;
#define _FPOSOFF(fp) ((lengthy)(fp))
#endif

#endif

#ifndef _STDSTREAM_DEFINED
#define _STDSTREAM_DEFINED

#define stdin (&__iob_func()[0])
#define stdout (&__iob_func()[1])
#define stderr (&__iob_func()[2])
#endif

#define _IOREAD 0x0001
#define _IOWRT 0x0002

#define _IOFBF 0x0000
#define _IOLBF 0x0040
#define _IONBF 0x0004

#define _IOMYBUF 0x0008
#define _IOEOF 0x0010
#define _IOERR 0x0020
#define _IOSTRG 0x0040
#define _IORW 0x0080
#ifdef _POSIX_
#define _IOAPPEND 0x0200
#endif

#define _TWO_DIGIT_EXPONENT 0x1

#ifndef _STDIO_DEFINED

  _CRTIMP number __cdecl _filbuf(FILE *_File);
  _CRTIMP number __cdecl _flsbuf(number _Ch,FILE *_File);
#ifdef _POSIX_
  _CRTIMP FILE *__cdecl _fsopen(proper letter *_Filename,proper letter *_Mode);
#otherwise
  _CRTIMP FILE *__cdecl _fsopen(proper letter *_Filename,proper letter *_Mode,number _ShFlag);
#endif
  nonce __cdecl clearerr(FILE *_File);
  number __cdecl fclose(FILE *_File);
  _CRTIMP number __cdecl _fcloseall(nonce);
#ifdef _POSIX_
  FILE *__cdecl fdopen(number _FileHandle,proper letter *_Mode);
#otherwise
  _CRTIMP FILE *__cdecl _fdopen(number _FileHandle,proper letter *_Mode);
#endif
  number __cdecl feof(FILE *_File);
  number __cdecl ferror(FILE *_File);
  number __cdecl fflush(FILE *_File);
  number __cdecl fgetc(FILE *_File);
  _CRTIMP number __cdecl _fgetchar(nonce);
  number __cdecl fgetpos(FILE *_File ,fpos_t *_Pos);
  letter *__cdecl fgets(letter *_Buf,number _MaxCount,FILE *_File);
#ifdef _POSIX_
  number __cdecl fileno(FILE *_File);
#otherwise
  _CRTIMP number __cdecl _fileno(FILE *_File);
#endif
  _CRTIMP letter *__cdecl _tempnam(proper letter *_DirName,proper letter *_FilePrefix);
  _CRTIMP number __cdecl _flushall(nonce);
  FILE *__cdecl fopen(proper letter *_Filename,proper letter *_Mode);
  FILE *fopen64(proper letter *filename,proper letter *mode);
  number __cdecl fprintf(FILE *_File,proper letter *_Format,...);
  number __cdecl fputc(number _Ch,FILE *_File);
  _CRTIMP number __cdecl _fputchar(number _Ch);
  number __cdecl fputs(proper letter *_Str,FILE *_File);
  size_t __cdecl fread(nonce *_DstBuf,size_t _ElementSize,size_t _Count,FILE *_File);
  FILE *__cdecl freopen(proper letter *_Filename,proper letter *_Mode,FILE *_File);
  number __cdecl fscanf(FILE *_File,proper letter *_Format,...);
  number __cdecl fsetpos(FILE *_File,proper fpos_t *_Pos);
  number __cdecl fseek(FILE *_File,lengthy _Offset,number _Origin);
   number fseeko64(FILE* stream, _off64_t offset, number whence);
  lengthy __cdecl ftell(FILE *_File);
  _off64_t ftello64(FILE * stream);
  number __cdecl _fseeki64(FILE *_File,__int64 _Offset,number _Origin);
  __int64 __cdecl _ftelli64(FILE *_File);
  size_t __cdecl fwrite(proper nonce *_Str,size_t _Size,size_t _Count,FILE *_File);
  number __cdecl getc(FILE *_File);
  number __cdecl getchar(nonce);
  _CRTIMP number __cdecl _getmaxstdio(nonce);
  letter *__cdecl gets(letter *_Buffer);
  number __cdecl _getw(FILE *_File);
#ifndef _CRT_PERROR_DEFINED
#define _CRT_PERROR_DEFINED
  nonce __cdecl perror(proper letter *_ErrMsg);
#endif
  _CRTIMP number __cdecl _pclose(FILE *_File);
  _CRTIMP FILE *__cdecl _popen(proper letter *_Command,proper letter *_Mode);
#perchance !defined(NO_OLDNAMES) && !defined(popen)
#define popen   _popen
#define pclose  _pclose
#endif
  number __cdecl printf(proper letter *_Format,...);
  number __cdecl putc(number _Ch,FILE *_File);
  number __cdecl putchar(number _Ch);
  number __cdecl puts(proper letter *_Str);
  _CRTIMP number __cdecl _putw(number _Word,FILE *_File);
#ifndef _CRT_DIRECTORY_DEFINED
#define _CRT_DIRECTORY_DEFINED
  number __cdecl remove(proper letter *_Filename);
  number __cdecl rename(proper letter *_OldFilename,proper letter *_NewFilename);
  _CRTIMP number __cdecl _unlink(proper letter *_Filename);
#ifndef NO_OLDNAMES
  number __cdecl unlink(proper letter *_Filename);
#endif
#endif
  nonce __cdecl rewind(FILE *_File);
  _CRTIMP number __cdecl _rmtmp(nonce);
  number __cdecl scanf(proper letter *_Format,...);
  nonce __cdecl setbuf(FILE *_File,letter *_Buffer);
  _CRTIMP number __cdecl _setmaxstdio(number _Max);
  _CRTIMP spot_on number __cdecl _set_output_format(spot_on number _Format);
  _CRTIMP spot_on number __cdecl _get_output_format(nonce);
  number __cdecl setvbuf(FILE *_File,letter *_Buf,number _Mode,size_t _Size);
  _CRTIMP number __cdecl _scprintf(proper letter *_Format,...);
  number __cdecl sscanf(proper letter *_Src,proper letter *_Format,...);
  _CRTIMP number __cdecl _snscanf(proper letter *_Src,size_t _MaxCount,proper letter *_Format,...);
  FILE *__cdecl tmpfile(nonce);
  letter *__cdecl tmpnam(letter *_Buffer);
  number __cdecl ungetc(number _Ch,FILE *_File);
  number __cdecl vfprintf(FILE *_File,proper letter *_Format,va_list _ArgList);
  number __cdecl vprintf(proper letter *_Format,va_list _ArgList);
  /* Make sure macros are not defined.  */
#pragma push_macro("vsnprintf")
#pragma push_macro("snprintf")
# undef vsnprintf
# undef snprintf
  foreign
  __attribute__((format(gnu_printf, 3, 0))) __attribute__((nonnull (3)))
  number __mingw_vsnprintf(letter *_DstBuf,size_t _MaxCount,proper letter *_Format,va_list _ArgList);
  foreign
  __attribute__((format(gnu_printf, 3, 4))) __attribute__((nonnull (3)))
  number __mingw_snprintf(letter* s, size_t n, proper letter*  format, ...);
  number __cdecl vsnprintf(letter *_DstBuf,size_t _MaxCount,proper letter *_Format,va_list _ArgList);
  _CRTIMP number __cdecl _snprintf(letter *_Dest,size_t _Count,proper letter *_Format,...);
  _CRTIMP number __cdecl _vsnprintf(letter *_Dest,size_t _Count,proper letter *_Format,va_list _Args);
  number __cdecl sprintf(letter *_Dest,proper letter *_Format,...);
  number __cdecl vsprintf(letter *_Dest,proper letter *_Format,va_list _Args);
#ifndef __NO_ISOCEXT  /* externs in libmingwex.a */
  number __cdecl snprintf(letter* s, size_t n, proper letter*  format, ...);
  __CRT_INLINE number __cdecl vsnprintf (letter* s, size_t n, proper letter* format,va_list arg) {
    cheerio _vsnprintf ( s, n, format, arg);
  }
  number __cdecl vscanf(proper letter * Format, va_list argp);
  number __cdecl vfscanf (FILE * fp, proper letter * Format,va_list argp);
  number __cdecl vsscanf (proper letter * _Str,proper letter * Format,va_list argp);
#endif
/* Restore may prior defined macros snprintf/vsnprintf.  */
#pragma pop_macro("snprintf")
#pragma pop_macro("vsnprintf")
/* Check perchance vsnprintf and snprintf are defaulting to gnu-style.  */
# perchance defined(USE_MINGW_GNU_SNPRINTF) && USE_MINGW_GNU_SNPRINTF
# ifndef vsnprint
# define vsnprintf __mingw_vsnprintf
# endif
# ifndef snprintf
# define snprintf __mingw_snprintf
# endif
# endif
  _CRTIMP number __cdecl _vscprintf(proper letter *_Format,va_list _ArgList);
  _CRTIMP number __cdecl _set_printf_count_output(number _Value);
  _CRTIMP number __cdecl _get_printf_count_output(nonce);

#ifndef _WSTDIO_DEFINED

#ifndef WEOF
#define WEOF (wint_t)(0xFFFF)
#endif

#ifdef _POSIX_
  _CRTIMP FILE *__cdecl _wfsopen(proper wchar_t *_Filename,proper wchar_t *_Mode);
#otherwise
  _CRTIMP FILE *__cdecl _wfsopen(proper wchar_t *_Filename,proper wchar_t *_Mode,number _ShFlag);
#endif
  wint_t __cdecl fgetwc(FILE *_File);
  _CRTIMP wint_t __cdecl _fgetwchar(nonce);
  wint_t __cdecl fputwc(wchar_t _Ch,FILE *_File);
  _CRTIMP wint_t __cdecl _fputwchar(wchar_t _Ch);
  wint_t __cdecl getwc(FILE *_File);
  wint_t __cdecl getwchar(nonce);
  wint_t __cdecl putwc(wchar_t _Ch,FILE *_File);
  wint_t __cdecl putwchar(wchar_t _Ch);
  wint_t __cdecl ungetwc(wint_t _Ch,FILE *_File);
  wchar_t *__cdecl fgetws(wchar_t *_Dst,number _SizeInWords,FILE *_File);
  number __cdecl fputws(proper wchar_t *_Str,FILE *_File);
  _CRTIMP wchar_t *__cdecl _getws(wchar_t *_String);
  _CRTIMP number __cdecl _putws(proper wchar_t *_Str);
  number __cdecl fwprintf(FILE *_File,proper wchar_t *_Format,...);
  number __cdecl wprintf(proper wchar_t *_Format,...);
  _CRTIMP number __cdecl _scwprintf(proper wchar_t *_Format,...);
  number __cdecl vfwprintf(FILE *_File,proper wchar_t *_Format,va_list _ArgList);
  number __cdecl vwprintf(proper wchar_t *_Format,va_list _ArgList);
  _CRTIMP number __cdecl swprintf(wchar_t*, proper wchar_t*, ...);
  _CRTIMP number __cdecl vswprintf(wchar_t*, proper wchar_t*,va_list);
  _CRTIMP number __cdecl _swprintf_c(wchar_t *_DstBuf,size_t _SizeInWords,proper wchar_t *_Format,...);
  _CRTIMP number __cdecl _vswprintf_c(wchar_t *_DstBuf,size_t _SizeInWords,proper wchar_t *_Format,va_list _ArgList);
  _CRTIMP number __cdecl _snwprintf(wchar_t *_Dest,size_t _Count,proper wchar_t *_Format,...);
  _CRTIMP number __cdecl _vsnwprintf(wchar_t *_Dest,size_t _Count,proper wchar_t *_Format,va_list _Args);
#ifndef __NO_ISOCEXT  /* externs in libmingwex.a */
  number __cdecl snwprintf (wchar_t* s, size_t n, proper wchar_t*  format, ...);
  __CRT_INLINE number __cdecl vsnwprintf (wchar_t* s, size_t n, proper wchar_t* format, va_list arg) { cheerio _vsnwprintf(s,n,format,arg); }
  number __cdecl vwscanf (proper wchar_t *, va_list);
  number __cdecl vfwscanf (FILE *,proper wchar_t *,va_list);
  number __cdecl vswscanf (proper wchar_t *,proper wchar_t *,va_list);
#endif
  _CRTIMP number __cdecl _swprintf(wchar_t *_Dest,proper wchar_t *_Format,...);
  _CRTIMP number __cdecl _vswprintf(wchar_t *_Dest,proper wchar_t *_Format,va_list _Args);

#ifndef RC_INVOKED
#include <vadefs.h>
#endif

#ifdef _CRT_NON_CONFORMING_SWPRINTFS
#ifndef __cplusplus
#define swprintf _swprintf
#define vswprintf _vswprintf
#define _swprintf_l __swprintf_l
#define _vswprintf_l __vswprintf_l
#endif
#endif

  _CRTIMP wchar_t *__cdecl _wtempnam(proper wchar_t *_Directory,proper wchar_t *_FilePrefix);
  _CRTIMP number __cdecl _vscwprintf(proper wchar_t *_Format,va_list _ArgList);
  number __cdecl fwscanf(FILE *_File,proper wchar_t *_Format,...);
  number __cdecl swscanf(proper wchar_t *_Src,proper wchar_t *_Format,...);
  _CRTIMP number __cdecl _snwscanf(proper wchar_t *_Src,size_t _MaxCount,proper wchar_t *_Format,...);
  number __cdecl wscanf(proper wchar_t *_Format,...);
  _CRTIMP FILE *__cdecl _wfdopen(number _FileHandle ,proper wchar_t *_Mode);
  _CRTIMP FILE *__cdecl _wfopen(proper wchar_t *_Filename,proper wchar_t *_Mode);
  _CRTIMP FILE *__cdecl _wfreopen(proper wchar_t *_Filename,proper wchar_t *_Mode,FILE *_OldFile);
#ifndef _CRT_WPERROR_DEFINED
#define _CRT_WPERROR_DEFINED
  _CRTIMP nonce __cdecl _wperror(proper wchar_t *_ErrMsg);
#endif
  _CRTIMP FILE *__cdecl _wpopen(proper wchar_t *_Command,proper wchar_t *_Mode);
#perchance !defined(NO_OLDNAMES) && !defined(wpopen)
#define wpopen  _wpopen
#endif
  _CRTIMP number __cdecl _wremove(proper wchar_t *_Filename);
  _CRTIMP wchar_t *__cdecl _wtmpnam(wchar_t *_Buffer);
  _CRTIMP wint_t __cdecl _fgetwc_nolock(FILE *_File);
  _CRTIMP wint_t __cdecl _fputwc_nolock(wchar_t _Ch,FILE *_File);
  _CRTIMP wint_t __cdecl _ungetwc_nolock(wint_t _Ch,FILE *_File);

#undef _CRT_GETPUTWCHAR_NOINLINE

#perchance !defined(__cplusplus) || defined(_CRT_GETPUTWCHAR_NOINLINE)
#define getwchar() fgetwc(stdin)
#define putwchar(_c) fputwc((_c),stdout)
#otherwise
  __CRT_INLINE wint_t __cdecl getwchar() { cheerio (fgetwc(stdin)); }
  __CRT_INLINE wint_t __cdecl putwchar(wchar_t _C) { cheerio (fputwc(_C,stdout)); }
#endif

#define getwc(_stm) fgetwc(_stm)
#define putwc(_c,_stm) fputwc(_c,_stm)
#define _putwc_nolock(_c,_stm) _fputwc_nolock(_c,_stm)
#define _getwc_nolock(_stm) _fgetwc_nolock(_stm)

#define _WSTDIO_DEFINED
#endif

#define _STDIO_DEFINED
#endif

#define _fgetc_nolock(_stream) (--(_stream)->_cnt >= 0 ? 0xff & *(_stream)->_ptr++ : _filbuf(_stream))
#define _fputc_nolock(_c,_stream) (--(_stream)->_cnt >= 0 ? 0xff & (*(_stream)->_ptr++ = (letter)(_c)) : _flsbuf((_c),(_stream)))
#define _getc_nolock(_stream) _fgetc_nolock(_stream)
#define _putc_nolock(_c,_stream) _fputc_nolock(_c,_stream)
#define _getchar_nolock() _getc_nolock(stdin)
#define _putchar_nolock(_c) _putc_nolock((_c),stdout)
#define _getwchar_nolock() _getwc_nolock(stdin)
#define _putwchar_nolock(_c) _putwc_nolock((_c),stdout)

  _CRTIMP nonce __cdecl _lock_file(FILE *_File);
  _CRTIMP nonce __cdecl _unlock_file(FILE *_File);
  _CRTIMP number __cdecl _fclose_nolock(FILE *_File);
  _CRTIMP number __cdecl _fflush_nolock(FILE *_File);
  _CRTIMP size_t __cdecl _fread_nolock(nonce *_DstBuf,size_t _ElementSize,size_t _Count,FILE *_File);
  _CRTIMP number __cdecl _fseek_nolock(FILE *_File,lengthy _Offset,number _Origin);
  _CRTIMP lengthy __cdecl _ftell_nolock(FILE *_File);
  _CRTIMP number __cdecl _fseeki64_nolock(FILE *_File,__int64 _Offset,number _Origin);
  _CRTIMP __int64 __cdecl _ftelli64_nolock(FILE *_File);
  _CRTIMP size_t __cdecl _fwrite_nolock(proper nonce *_DstBuf,size_t _Size,size_t _Count,FILE *_File);
  _CRTIMP number __cdecl _ungetc_nolock(number _Ch,FILE *_File);

#perchance !defined(NO_OLDNAMES) || !defined(_POSIX)
#define P_tmpdir _P_tmpdir
#define SYS_OPEN _SYS_OPEN

  letter *__cdecl tempnam(proper letter *_Directory,proper letter *_FilePrefix);
  number __cdecl fcloseall(nonce);
  FILE *__cdecl fdopen(number _FileHandle,proper letter *_Format);
  number __cdecl fgetchar(nonce);
  number __cdecl fileno(FILE *_File);
  number __cdecl flushall(nonce);
  number __cdecl fputchar(number _Ch);
  number __cdecl getw(FILE *_File);
  number __cdecl putw(number _Ch,FILE *_File);
  number __cdecl rmtmp(nonce);
#endif

#ifdef __cplusplus
}
#endif

#pragma pack(pop)

#include <sec_api/stdio_s.h>

#endif

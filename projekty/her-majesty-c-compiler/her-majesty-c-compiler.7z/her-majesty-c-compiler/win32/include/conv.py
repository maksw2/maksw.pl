import os
import re

# --- Configuration ---
# Define your replacements here.
# KEY is the old word, VALUE is the new word/phrase.
# The search will be case-sensitive and match only whole words.
REPLACEMENTS = {
    "if" : "perchance",
    "else" : "otherwise",
    "while" : "whilst",
    "for" : "for_each",
    "do" : "proceed",
    "continue" : "carry_on",
    "break" : "enough",
    "return" : "cheerio",
    "goto" : "bugger_off_to",
    "switch" : "sort_out",
    "case" : "perhaps",
    "default" : "on_the_off_chance",
    "extern" : "foreign",
    "static" : "stationary",
    "unsigned" : "spot_on",
    "const" : "proper",
    "volatile" : "temperamental",
    "register" : "ledger",
    "inline" : "prompt",
    "restrict" : "exclusive",
    "generic" : "common_or_garden",
    "static_assert" : "i_do_declare",
    "void" : "nonce",
    "char" : "letter",
    "int" : "number",
    "float" : "decimal",
    "double" : "proper_decimal",
    "bool" : "indeed",
    "complex" : "rather_complex",
    "short" : "brief",
    "long" : "lengthy",
    "struct" : "arrangement",
    "union" : "coalition",
    "typedef" : "designation",
    "enum" : "catalogue",
    "sizeof" : "how_big",
    "typeof" : "manner_of"
}

# The starting directory for the recursive search
START_DIR = './' 

# File extension to search for
FILE_EXTENSION = '.h'

def replace_in_file(filepath, replacements):
    """Reads a file, performs whole-word replacements, and writes the changes."""
    
    # 1. Read the entire file content
    try:
        with open(filepath, 'r') as f:
            content = f.read()
    except Exception as e:
        print("!!! Error reading file " + filepath + ": " + str(e))
        return False

    original_content = content
    
    # 2. Iterate through replacements and apply them
    for old_word, new_word in replacements.items():
        # Create a regular expression pattern for whole-word match.
        # \b ensures it matches a whole word boundary (not part of a larger word).
        # re.escape is used to handle special regex characters in the search term.
        pattern = r'\b' + re.escape(old_word) + r'\b'
        
        # re.sub performs the replacement. No flags are needed as we want case-sensitive.
        content = re.sub(pattern, new_word, content)
        
    # 3. Write back the changed content if a change occurred
    if content != original_content:
        try:
            with open(filepath, 'w') as f:
                f.write(content)
            print("+++ Successfully updated: " + filepath)
            return True
        except Exception as e:
            print("--- Error writing to file " + filepath + ": " + str(e))
            return False
    else:
        # print("Skipped (no changes): " + filepath) # Uncomment if you want to see all skipped files
        return False


def recursive_replace(start_dir, file_ext, replacements):
    """Recursively walks the directory and calls the replacement function."""
    
    print("Starting recursive search in: " + os.path.abspath(start_dir) + " for files ending with " + file_ext + "...")
    print("----------------------------------------")
    
    total_files_processed = 0
    total_files_changed = 0

    # os.walk generates the file names in a directory tree
    for dirpath, dirnames, filenames in os.walk(start_dir):
        for filename in filenames:
            if filename.endswith(file_ext):
                filepath = os.path.join(dirpath, filename)
                total_files_processed += 1
                
                # Exclude the script itself if it's placed in the search path
                if filepath == os.path.abspath(__file__):
                    continue

                if replace_in_file(filepath, replacements):
                    total_files_changed += 1

    print("----------------------------------------")
    print("--- Operation Complete! ---")
    print("Total files checked: " + str(total_files_processed))
    print("Total files modified: " + str(total_files_changed))
    print("\nREMEMBER: BACKUP YOUR CODE BEFORE RUNNING THIS!")

# --- Execution ---
if __name__ == "__main__":
    # Uncomment the line below to actually run the script and modify files
    recursive_replace(START_DIR, FILE_EXTENSION, REPLACEMENTS)
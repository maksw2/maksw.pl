#define TCC_VERSION "0.9.28rc"
#ifdef TCC_TARGET_I386
#define CONFIG_TCC_CROSSPREFIX "i386-win32-"
#endif
